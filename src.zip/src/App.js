import React from 'react';
import Head from './components/head'
import Banner from './components/banner'
import './App.scss'
function App() {
  return (
    <div className="App">
      <Head></Head>
      <Banner></Banner>
    </div>
  );
}

export default App;
